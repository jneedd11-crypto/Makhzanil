package com.example.makhzani

import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Calendar

class AddItemActivity : AppCompatActivity() {

    private var expiry: Long = System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000
    private var imagePath: String? = null
    private lateinit var dateBtn: Button
    private lateinit var preview: ImageView

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val file = File(filesDir, "img_\${System.currentTimeMillis()}.jpg")
            contentResolver.openInputStream(uri)?.use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            }
            imagePath = file.absolutePath
            preview.setImageURI(uri)
            preview.visibility = android.view.View.VISIBLE
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر حفظ الصورة", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.parseColor("#F0F2F5"))
        }

        val title = TextView(this).apply {
            text = if (intent.hasExtra("id")) "✏️ تعديل صنف" else "➕ صنف جديد"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#1F2430"))
        }

        val nameBox = EditText(this).apply { hint = "اسم الصنف (مثل: حليب، باراسيتامول)" }
        val catSpin = Spinner(this)
        val cats = listOf("غذاء", "دواء", "تنظيف", "أخرى")
        catSpin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats)
        var category = "غذاء"
        catSpin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) { category = cats[pos] }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        dateBtn = Button(this).apply {
            styleBtn(this, "#4A7FB5")
            updateDateText()
            setOnClickListener {
                val c = Calendar.getInstance()
                c.timeInMillis = expiry
                DatePickerDialog(this@AddItemActivity, { _, y, m, d ->
                    val cal = Calendar.getInstance()
                    cal.set(y, m, d, 0, 0, 0)
                    expiry = cal.timeInMillis
                    updateDateText()
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
            }
        }

        val qtyBox = EditText(this).apply {
            hint = "الكمية (رقم)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val noteBox = EditText(this).apply { hint = "ملاحظة (اختياري)" }

        preview = ImageView(this).apply {
            visibility = android.view.View.GONE
            adjustViewBounds = true
        }

        val imgBtn = Button(this).apply {
            text = "🖼 إضافة صورة"
            styleBtn(this, "#8A9099")
            setOnClickListener { pickImage.launch("image/*") }
        }

        val saveBtn = Button(this).apply {
            text = "💾 حفظ"
            textSize = 17f
            styleBtn(this, "#2E7D32")
            setOnClickListener {
                val name = nameBox.text.toString().trim()
                if (name.isEmpty()) { toast("اكتب اسم الصنف"); return@setOnClickListener }
                val qty = qtyBox.text.toString().toIntOrNull() ?: 1
                val res = Intent().apply {
                    putExtra("id", intent.getIntExtra("id", -1))
                    putExtra("name", name)
                    putExtra("category", category)
                    putExtra("expiry", expiry)
                    putExtra("quantity", qty)
                    putExtra("note", noteBox.text.toString())
                    putExtra("image", imagePath)
                    putExtra("shopping", intent.getBooleanExtra("shoppingMode", false))
                }
                setResult(RESULT_OK, res)
                finish()
            }
        }

        root.addView(title)
        root.addView(label("الاسم")); root.addView(nameBox)
        root.addView(label("التصنيف")); root.addView(catSpin)
        root.addView(label("تاريخ الانتهاء")); root.addView(dateBtn)
        root.addView(label("الكمية")); root.addView(qtyBox)
        root.addView(label("ملاحظة")); root.addView(noteBox)
        root.addView(imgBtn)
        root.addView(preview)
        root.addView(saveBtn)
        setContentView(root)

        // تعبئة البيانات عند التعديل
        if (intent.hasExtra("name")) {
            nameBox.setText(intent.getStringExtra("name"))
            val c = intent.getStringExtra("category") ?: "غذاء"
            catSpin.setSelection(cats.indexOf(c).coerceAtLeast(0))
            expiry = intent.getLongExtra("expiry", expiry)
            updateDateText()
            qtyBox.setText(intent.getIntExtra("quantity", 1).toString())
            noteBox.setText(intent.getStringExtra("note") ?: "")
            imagePath = intent.getStringExtra("image")
            imagePath?.let {
                val f = File(it)
                if (f.exists()) { preview.setImageURI(android.net.Uri.fromFile(f)); preview.visibility = android.view.View.VISIBLE }
            }
        }
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(Color.parseColor("#4A7FB5"))
        setPadding(0, 14, 0, 2)
    }

    private fun styleBtn(b: Button, color: String) {
        val bg = GradientDrawable().apply { cornerRadius = 26f; setColor(Color.parseColor(color)) }
        b.background = bg
        b.setTextColor(Color.WHITE)
    }

    private fun updateDateText() {
        val c = Calendar.getInstance().apply { timeInMillis = expiry }
        dateBtn.text = "📅 \${c.get(Calendar.YEAR)}/\${c.get(Calendar.MONTH) + 1}/\${c.get(Calendar.DAY_OF_MONTH)}"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
