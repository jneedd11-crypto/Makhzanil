package com.example.makhzani

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String,          // دواء / غذاء / تنظيف / أخرى
    val expiry: Long,              // تاريخ الانتهاء بالمللي ثانية
    val quantity: Int = 1,
    val note: String = "",
    val imagePath: String? = null,
    val shopping: Boolean = false, // في قائمة التسوق
    val lastNotifyDay: Long = 0    // لتجنب تكرار الإشعار يوميا
)

@Dao
interface ItemDao {
    @Query("SELECT * FROM items ORDER BY expiry ASC")
    suspend fun getAll(): List<Item>

    @Query("SELECT * FROM items WHERE shopping = 0 AND expiry <= :limit AND expiry > :now")
    suspend fun getExpiring(now: Long, limit: Long): List<Item>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: Item): Long

    @Update
    suspend fun update(item: Item)

    @Delete
    suspend fun delete(item: Item)
}

@Database(entities = [Item::class], version = 1)
abstract class AppDB : RoomDatabase() {
    abstract fun itemDao(): ItemDao
    companion object {
        @Volatile private var instance: AppDB? = null
        fun get(ctx: Context): AppDB =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(ctx, AppDB::class.java, "makhzani.db")
                    .build().also { instance = it }
            }
    }
}
