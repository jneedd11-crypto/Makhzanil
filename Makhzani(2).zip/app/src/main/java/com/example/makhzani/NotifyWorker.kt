package com.example.makhzani

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class NotifyWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val db = AppDB.get(applicationContext)
        val now = System.currentTimeMillis()
        val dayMs = 24L * 60 * 60 * 1000
        val today = now / dayMs
        val limit = now + 7 * dayMs  // نبه قبل أسبوع
        val expiring = db.itemDao().getExpiring(now, limit)
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        ensureChannel(nm)
        for (item in expiring) {
            if (item.lastNotifyDay == today) continue
            val daysLeft = ((item.expiry - now) / dayMs).toInt()
            val text = if (daysLeft <= 0) "منتهي الصلاحية!"
                           else "ينتهي خلال ${daysLeft} يوم"
            val n = NotificationCompat.Builder(applicationContext, "expiry")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("تنبيه مخزني: ${item.name}")
                .setContentText("${item.category} — $text")
                .setAutoCancel(true)
                .build()
            nm.notify(item.id, n)
            db.itemDao().update(item.copy(lastNotifyDay = today))
        }
        return Result.success()
    }

    companion object {
        fun ensureChannel(nm: NotificationManager) {
            nm.createNotificationChannel(
                NotificationChannel("expiry", "تنبيهات الانتهاء", NotificationManager.IMPORTANCE_DEFAULT))
        }
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<NotifyWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(1, TimeUnit.HOURS).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("expiry", androidx.work.ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
