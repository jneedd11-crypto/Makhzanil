package com.example.makhzani

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var dao: ItemDao
    private lateinit var listView: ListView
    private lateinit var emptyText: TextView
    private var allItems = listOf<Item>()
    private var shown = listOf<Item>()
    private var filterCat = "الكل"
    private var search = ""
    private var showShopping = false

    private val addLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) {
            val d = res.data ?: return@registerForActivityResult
            val item = Item(
                name = d.getStringExtra("name") ?: return@registerForActivityResult,
                category = d.getStringExtra("category") ?: "أخرى",
                expiry = d.getLongExtra("expiry", 0),
                quantity = d.getIntExtra("quantity", 1),
                note = d.getStringExtra("note") ?: "",
                imagePath = d.getStringExtra("image"),
                shopping = d.getBooleanExtra("shopping", false)
            )
            lifecycleScope.launch(Dispatchers.IO) { dao.insert(item); reload() }
        }
    }

    private val editLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) {
            val d = res.data ?: return@registerForActivityResult
            val id = d.getIntExtra("id", -1)
            val old = allItems.find { it.id == id } ?: return@registerForActivityResult
            val updated = old.copy(
                name = d.getStringExtra("name") ?: old.name,
                category = d.getStringExtra("category") ?: old.category,
                expiry = d.getLongExtra("expiry", old.expiry),
                quantity = d.getIntExtra("quantity", old.quantity),
                note = d.getStringExtra("note") ?: old.note,
                imagePath = d.getStringExtra("image") ?: old.imagePath
            )
            lifecycleScope.launch(Dispatchers.IO) { dao.update(updated); reload() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dao = AppDB.get(this).itemDao()
        NotifyWorker.schedule(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
            setBackgroundColor(Color.parseColor("#F0F2F5"))
        }

        val title = TextView(this).apply {
            text = "📦 مخزني"
            textSize = 24f
            setTextColor(Color.parseColor("#1F2430"))
            gravity = Gravity.CENTER
        }
        val searchBox = EditText(this).apply {
            hint = "🔍 ابحث عن صنف..."
        }

        // صف الفلاتر
        val filterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cats = listOf("الكل", "دواء", "غذاء", "تنظيف", "أخرى", "🛒 التسوق")
        val catBtns = mutableListOf<Button>()
        cats.forEach { cat ->
            val b = Button(this).apply {
                text = cat
                setOnClickListener {
                    if (cat == "🛒 التسوق") { showShopping = true; filterCat = "الكل" }
                    else { showShopping = false; filterCat = cat }
                    catBtns.forEach { it.alpha = if (it == b) 1f else 0.55f }
                    applyFilter()
                }
            }
            styleCat(b)
            catBtns.add(b)
            filterRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 3, 3, 3) })
        }

        emptyText = TextView(this).apply {
            text = "لا توجد أصناف — اضغط ➕ لإضافة أول صنف"
            textSize = 15f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 60, 0, 0)
        }

        listView = ListView(this)
        listView.adapter = ItemsAdapter()
        listView.setOnItemClickListener { _, _, pos, _ -> showOptions(shown[pos]) }

        val addBtn = Button(this).apply {
            text = "➕ إضافة صنف"
            textSize = 17f
            val bg = GradientDrawable().apply { cornerRadius = 30f; setColor(Color.parseColor("#2E7D32")) }
            background = bg
            setTextColor(Color.WHITE)
            setOnClickListener { addLauncher.launch(Intent(this@MainActivity, AddItemActivity::class.java)) }
        }

        root.addView(title)
        root.addView(searchBox)
        root.addView(filterRow)
        root.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(emptyText)
        root.addView(addBtn)
        setContentView(root)

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                search = s?.toString() ?: ""; applyFilter()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        reload()
    }

    override fun onResume() { super.onResume(); if (::dao.isInitialized) reload() }

    private fun styleCat(b: Button) {
        val bg = GradientDrawable().apply { cornerRadius = 26f; setColor(Color.parseColor("#4A7FB5")) }
        b.background = bg
        b.setTextColor(Color.WHITE)
        b.textSize = 12f
    }

    private fun reload() = lifecycleScope.launch(Dispatchers.IO) {
        allItems = dao.getAll()
        withContext(Dispatchers.Main) { applyFilter() }
    }

    private fun applyFilter() {
        shown = allItems.filter {
            (showShopping == it.shopping) &&
            (filterCat == "الكل" || it.category == filterCat) &&
            (search.isBlank() || it.name.contains(search, true))
        }
        emptyText.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        listView.visibility = if (shown.isEmpty()) View.GONE else View.VISIBLE
        (listView.adapter as BaseAdapter).notifyDataSetChanged()
    }

    private fun daysLeft(item: Item): Long =
        (item.expiry - System.currentTimeMillis()) / (24L * 60 * 60 * 1000)

    private fun badgeColor(item: Item): String {
        if (item.shopping) return "#8A9099"
        val d = daysLeft(item)
        return when {
            d < 0 -> "#D9534F"
            d <= 7 -> "#E67E22"
            d <= 30 -> "#F1C40F"
            else -> "#7CB342"
        }
    }

    private fun badgeText(item: Item): String {
        if (item.shopping) return "🛒 للشراء"
        val d = daysLeft(item)
        return when {
            d < 0 -> "منتهي منذ \${-d} يوم"
            d == 0L -> "ينتهي اليوم!"
            d == 1L -> "غدا"
            else -> "باقي \${d} يوم"
        }
    }

    private fun showOptions(item: Item) {
        val opts = if (item.shopping)
            arrayOf("✅ اشترَيته (أعد للمخزون)", "🗑 حذف")
        else
            arrayOf("✏️ تعديل", "🛒 نفد — انقل للتسوق", "🗑 حذف")
        AlertDialog.Builder(this).setTitle(item.name).setItems(opts) { _, which ->
            lifecycleScope.launch(Dispatchers.IO) {
                when {
                    item.shopping && which == 0 -> dao.update(item.copy(shopping = false, expiry = System.currentTimeMillis() + 180L * 24 * 60 * 60 * 1000))
                    item.shopping && which == 1 -> dao.delete(item)
                    !item.shopping && which == 0 -> {
                        withContext(Dispatchers.Main) {
                            val i = Intent(this@MainActivity, AddItemActivity::class.java)
                            i.putExtra("id", item.id)
                            i.putExtra("name", item.name)
                            i.putExtra("category", item.category)
                            i.putExtra("expiry", item.expiry)
                            i.putExtra("quantity", item.quantity)
                            i.putExtra("note", item.note)
                            i.putExtra("image", item.imagePath)
                            editLauncher.launch(i)
                        }
                        return@launch
                    }
                    !item.shopping && which == 1 -> dao.update(item.copy(shopping = true))
                    else -> dao.delete(item)
                }
                reload()
            }
        }.show()
    }

    private inner class ItemsAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(pos: Int) = shown[pos]
        override fun getItemId(pos: Int) = shown[pos].id.toLong()

        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val item = shown[pos]
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(20, 16, 20, 16)
                val bg = GradientDrawable().apply {
                    cornerRadius = 24f
                    setColor(Color.WHITE)
                }
                background = bg
            }
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            val nameTv = TextView(this@MainActivity).apply {
                text = "\${item.name}  (×\${item.quantity})"
                textSize = 17f
                setTextColor(Color.parseColor("#1F2430"))
            }
            val catTv = TextView(this@MainActivity).apply {
                text = item.category + (if (item.note.isNotBlank()) " — \${item.note}" else "")
                textSize = 12f
                setTextColor(Color.GRAY)
            }
            col.addView(nameTv)
            col.addView(catTv)
            val badge = TextView(this@MainActivity).apply {
                text = badgeText(item)
                textSize = 12f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                val bg = GradientDrawable().apply {
                    cornerRadius = 24f
                    setColor(Color.parseColor(badgeColor(item)))
                }
                background = bg
                setPadding(20, 10, 20, 10)
            }
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(badge)
            val wrap = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 4, 0, 4)
            }
            wrap.addView(row)
            return wrap
        }
    }
}
